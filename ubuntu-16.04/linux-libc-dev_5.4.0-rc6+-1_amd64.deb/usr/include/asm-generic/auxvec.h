#ifndef __ASM_GENERIC_AUXVEC_H
#define __ASM_GENERIC_AUXVEC_H
/*
 * Not all architectures need their own auxvec.h, the most
 * common definitions are already in linux/auxvec.h.
 */

#endif /* __ASM_GENERIC_AUXVEC_H */
